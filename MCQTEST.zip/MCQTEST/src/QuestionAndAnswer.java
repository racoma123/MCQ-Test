import java.io.*;
import java.util.Scanner;
public class QuestionAndAnswer {
    String line = "";
    public static double score =0;
    public static double wrongAnswer =0;
    Scanner sc = new Scanner(System.in);
    public  void MCQ(int choose) throws IOException {
        switch (choose) {
            case 1: {
                try {
                    {
                        File file = new File("JAVAMCQ.csv"); //  This is file of QUestion and Answer
                        Scanner scanner = new Scanner(file);// used the scanner to scan the file

                        while (scanner.hasNextLine()) { // to get the value in CSV  using hasNextline  until it become -1 or null
                            String line = scanner.nextLine(); // I store the scanner into line and cover line into string array
                            String[] QueAndAns = line.split(",");

                            System.out.println(" THIS IS JAVA BASIC TEST");
                            System.out.println();
                            System.out.println("Please answer carefully");
                            System.out.println(QueAndAns[0] + "\n" + QueAndAns[1] + "\n" + QueAndAns[2] + "\n" + QueAndAns[3] + "\n" + QueAndAns[4] + "\n" + QueAndAns[5]); // To Display the question and Answer
                            System.out.println("------------------------------------------------------------");
                            System.out.print(" Put Your Answer Here :    ");
                            String Ans = sc.next(); // ask the user to input the answer
                            System.out.println("------------------------------------------------------------");

                            if (QueAndAns[6].equalsIgnoreCase(Ans)) {
                                System.out.println("------------------------------------------------------------");
                                System.out.println("Your answer is correct....");
                                System.out.println("------------------------------------------------------------");
                                ++score; // the score will add if it's correct
                            }else {
                                System.out.println("------------------------------------------------------------");
                                System.out.println(" Your answer is Incorrect.... The answer is " + QueAndAns[6]);
                                System.out.println("------------------------------------------------------------");
                                ++wrongAnswer; // the wrong answer will add if it's incorrect
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 2: {
                try {
                    {
                        File file = new File("HTMLMCQ.csv");
                        Scanner scanner = new Scanner(file);

                        while (scanner.hasNextLine()) {
                            String line = scanner.nextLine();
                            String[] QueAndAns = line.split(",");

                            System.out.println("            ");
                            System.out.println("Please answer carefully");
                            System.out.println(QueAndAns[0] + "\n" + QueAndAns[1] + "\n" + QueAndAns[2] + "\n" + QueAndAns[3] + "\n" + QueAndAns[4] + "\n" + QueAndAns[5]);
                            System.out.println("------------------------------------------------------------");
                            System.out.print(" Put Your Answer Here :    ");
                            System.out.println();
                            System.out.println("------------------------------------------------------------");
                            String Ans = sc.next();
                            if (QueAndAns[6].equalsIgnoreCase(Ans)) {
                                System.out.println("------------------------------------------------------------");
                                System.out.println("Your answer is correct.");
                                System.out.println("------------------------------------------------------------");
                                ++score;

                            } else {
                                System.out.println("------------------------------------------------------------");
                                System.out.println("  Your answer is Incorrect.... The answer is " + QueAndAns[6]);
                                System.out.println("------------------------------------------------------------");
                                ++wrongAnswer;
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case 3: {
                try {
                    {
                        File file = new File("JAVASCRIPT.csv");
                        Scanner scanner = new Scanner(file);

                        while (scanner.hasNextLine()) {
                            String line = scanner.nextLine();
                            String[] QueAndAns = line.split(",");

                            System.out.println(" ");
                            System.out.println("Please answer carefully");
                            System.out.println(QueAndAns[0] + "\n" + QueAndAns[1] + "\n" + QueAndAns[2] + "\n" + QueAndAns[3] + "\n" + QueAndAns[4] + "\n" + QueAndAns[5]);
                            System.out.println("------------------------------------------------------------");
                            System.out.print(" Put Your Answer Here :    ");
                            System.out.println();
                            System.out.println("------------------------------------------------------------");
                            String Ans = sc.next();
                            if (QueAndAns[6].equalsIgnoreCase(Ans)) {
                                System.out.println("------------------------------------------------------------");
                                System.out.println("Your answer is correct.");
                                System.out.println("------------------------------------------------------------");
                                ++score;
                            } else {
                                System.out.println("------------------------------------------------------------");
                                System.out.println(" Your answer is Incorrect.... The answer is " + QueAndAns[6]);
                                System.out.println("------------------------------------------------------------");
                                ++wrongAnswer;
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }
}
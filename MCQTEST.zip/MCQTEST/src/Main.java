import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        welcome();
        ExaminerName examinerName = new ExaminerName();
        examinerName.setUserName(getNameOfUser());
//------------------------------------------------------------------
//------------------------------------------------------------------
        typeOfMCQ();
        examinerName.setChoose(choiceMCQType());
        QuestionAndAnswer questionAndAnswer = new QuestionAndAnswer();
        questionAndAnswer.MCQ(examinerName.getChoose());
//------------------------------------------------------------------
 //-----------------------------------------------------------------
        Result result = new Result();
        System.out.println("Hello "+examinerName.getUserName());
        result.mcqResult();
//------------------------------------------------------------------
//------------------------------------------------------------------jdfsdfdfgdgf
    }
    public  static void welcome(){
        System.out.println("----------------------------");
        System.out.println("    WELCOME TO MQC TEST     ");
        System.out.println("         GOODLUCK           ");
        System.out.println("----------------------------");
    }
    public static String  getNameOfUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("ENTER YOUR FULL NAME : ");
        String name = scanner.nextLine();
        System.out.println("");
        return name;
    }
    public  static void typeOfMCQ(){
        System.out.println("------------------------------------------------------------");
        System.out.println("Please kindly choose what MCQ Question do you want.");
        System.out.println("------------------------------------------------------------");
        System.out.println("Choose your Multiple Choice Question Set. The Options are : ");
        System.out.println("------------------------------------------------------------");
        System.out.println("1. Java Basics");
        System.out.println("2. HTML       ");
        System.out.println("3. JavaScript ");
    }
    public static int choiceMCQType() {
        System.out.println("------------------------------------------------------------");
        System.out.println("Enter MCQ Question Set: ");
        System.out.println("------------------------------------------------------------");
        Scanner sc = new Scanner(System.in);
        int choose = sc.nextInt();
        System.out.println("");
        return choose;
    }

}
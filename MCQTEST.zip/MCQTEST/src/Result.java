public class Result extends  QuestionAndAnswer{
    double percentage;

    public void mcqResult(){
        percentage = (score/10)*100;
        System.out.println("You answered "+ score+ " Questions Right, "+ wrongAnswer+ "  Questions Wrong for a Total of 10 Questions. ");
        System.out.println("Congratulations!!! Your Score is "+ percentage +"%");

        if(score >=8 && score <=10){
            System.out.println("You passed the MCQ Test...");
        } else{
            System.out.println("You failed");
        }

    }
}

public class ExaminerName {
    private String userName;
    private int choose;
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public int getChoose() {
        return choose;
    }
    public void setChoose(int choose) {
        this.choose = choose;
    }
}
